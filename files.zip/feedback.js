// api/feedback.js
// 이 파일은 서버(Vercel)에서만 실행돼요. API 키는 여기서만 사용되고
// 학생/사용자 브라우저에는 절대 노출되지 않아요.
// OpenAI API (gpt-4o-mini, 비전 지원)를 사용합니다.

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'POST 요청만 허용됩니다.' });
  }

  const { base64, mediaType, name } = req.body || {};

  if (!base64 || !mediaType) {
    return res.status(400).json({ error: '이미지 데이터가 없습니다.' });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: '서버에 API 키가 설정되어 있지 않습니다. Vercel 환경변수를 확인해주세요.' });
  }

  const systemPrompt = `You are a warm, encouraging English writing teacher for Korean elementary school students (초등학생) at Sophie Writing Class, an English writing academy.

You will be shown a photo of a student's handwritten or typed English paragraph. Your job:
1. Transcribe the text as accurately as you can from the image.
2. Find grammar, spelling, word choice, and sentence structure issues appropriate to give feedback on for an elementary-level English learner.
3. Explain each issue in a way an 8-13 year old Korean student can understand, writing explanations in KOREAN, but keep the original English words/phrases as-is when quoting them.
4. Suggest a corrected, slightly improved rewrite of the whole paragraph in natural, elementary-level English (don't make it too advanced - keep the student's voice and ideas, just fix errors and improve clarity a little).
5. Give 2-3 short, actionable tips for what to focus on next time, written in Korean.
6. Give brief genuine praise for something the student did well, written in Korean.
7. Give an overall score out of 100 reflecting how well-written the piece is for their level (be encouraging - most reasonable attempts should score 65-90).

Respond ONLY with valid JSON, no markdown fences, no preamble, matching this exact schema:
{
  "transcribed_text": "string - the original text with errors marked using <err id=\\"1\\">wrong phrase</err> tags around each erroneous span, numbered sequentially",
  "score": number,
  "score_comment": "one short encouraging sentence in Korean about the overall writing",
  "corrections": [
    {
      "id": 1,
      "type": "문법 | 철자 | 어휘 | 문장구조 | 구두점",
      "wrong": "the incorrect text as written",
      "correct": "the corrected version",
      "explanation": "1-2 sentence explanation in Korean, friendly and clear, aimed at a Korean elementary student"
    }
  ],
  "praise": "2-3 sentences in Korean genuinely praising something specific the student did well",
  "rewrite": "the improved full paragraph in natural elementary-level English",
  "tips": ["tip 1 in Korean", "tip 2 in Korean", "tip 3 in Korean"]
}

If the image is unclear or you cannot read the text, still do your best to respond in the same JSON schema, setting transcribed_text to your best-effort reading and noting uncertainty in score_comment.`;

  const userText = `학생 이름: ${name || '학생'}. 사진 속 학생의 영어 라이팅을 첨삭해 주세요.`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        response_format: { type: 'json_object' },
        max_tokens: 1500,
        messages: [
          { role: 'system', content: systemPrompt },
          {
            role: 'user',
            content: [
              { type: 'text', text: userText },
              {
                type: 'image_url',
                image_url: { url: `data:${mediaType};base64,${base64}` }
              }
            ]
          }
        ]
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('OpenAI API error:', errText);
      return res.status(502).json({ error: 'AI 서버 호출에 실패했습니다.' });
    }

    const data = await response.json();
    const content = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;

    if (!content) {
      return res.status(502).json({ error: '결과를 받지 못했습니다.' });
    }

    let clean = content
      .trim()
      .replace(/^```json/, '')
      .replace(/^```/, '')
      .replace(/```$/, '')
      .trim();

    const parsed = JSON.parse(clean);
    return res.status(200).json(parsed);
  } catch (err) {
    console.error('Feedback handler error:', err);
    return res.status(500).json({ error: '첨삭 처리 중 오류가 발생했습니다.' });
  }
}
