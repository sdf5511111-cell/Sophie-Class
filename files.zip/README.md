# Sophie Writing Class 배포 가이드

학생이 라이팅 사진을 올리면 AI가 첨삭해주는 사이트입니다. (OpenAI API 사용)
아래 순서대로 따라오시면 **개발 지식 없이도** 실제 웹사이트를 만들 수 있어요.

---

## 1단계. OpenAI API 키 준비

이미 https://platform.openai.com 에서 키를 받으셨다면 이 단계는 넘어가셔도 돼요.
키를 잃어버렸다면:

1. https://platform.openai.com 접속 후 로그인
2. 왼쪽 메뉴 또는 상단에서 **API keys** 클릭
3. **Create new secret key** 클릭 → 이름 입력 (예: sophie-class) → 생성
4. `sk-`로 시작하는 키를 복사해서 안전한 곳에 저장 (다시 볼 수 없어요)
5. **Billing** 메뉴에서 결제 수단이 등록되어 있는지 확인 (사용한 만큼만 청구돼요)

이 프로젝트는 `gpt-4o-mini` 모델을 사용해요. 사진 인식 + 첨삭 생성이 가능하면서
비용이 매우 저렴한 모델이에요 (사진 1장 첨삭당 약 5~10원 수준).

---

## 2단계. GitHub에 코드 올리기

1. https://github.com 에서 무료 계정 만들기 (이미 있다면 생략)
2. 오른쪽 위 **+ → New repository** 클릭
3. 이름을 `sophie-writing-class` 로 입력 → **Create repository**
4. 저장소 페이지에서 **uploading an existing file** 링크 클릭
5. 이 폴더 안의 파일 전체(`api`, `public` 폴더와 `package.json`)를 드래그해서 업로드
6. 아래 **Commit changes** 버튼 클릭

---

## 3단계. Vercel로 배포하기

1. https://vercel.com 접속 → **Continue with GitHub**로 로그인 (같은 GitHub 계정 사용)
2. 대시보드에서 **Add New → Project** 클릭
3. 방금 만든 `sophie-writing-class` 저장소를 찾아서 **Import**
4. 배포 설정 화면에서 **Environment Variables** 섹션을 펼치고:
   - Name: `OPENAI_API_KEY`
   - Value: (1단계에서 복사한 sk-로 시작하는 키 붙여넣기)
   - **Add** 클릭
5. **Deploy** 버튼 클릭 → 1~2분 기다리기
6. 배포가 끝나면 `sophie-writing-class.vercel.app` 같은 주소가 생성돼요.
   이 주소가 바로 학생들이 접속할 실제 웹사이트 주소입니다.

---

## 4단계. 확인하기

1. 생성된 주소로 접속
2. 이름 입력 → 사진 업로드 → 제출하기
3. 첨삭 결과가 정상적으로 나오면 성공이에요!

---

## 참고사항

- **비용**: 호스팅(Vercel)은 무료입니다. 비용은 OpenAI API 사용량만큼만 발생하며,
  `gpt-4o-mini` 기준 사진 1장 첨삭당 약 5~10원 수준입니다. 하루 30명 사용해도
  월 1만 원이 안 됩니다.
- **품질을 더 높이고 싶다면**: `api/feedback.js` 파일에서 `model: 'gpt-4o-mini'` 부분을
  `model: 'gpt-4o'` 로 바꾸면 더 정교한 첨삭이 가능해요 (비용은 약 15배 더 비쌈).
- **도메인 변경**: Vercel 프로젝트 설정의 Domains 메뉴에서 원하는 커스텀 도메인
  (예: sophieclass.co.kr)을 연결할 수 있어요 (도메인은 별도 구매 필요).
- **코드 수정**: 첨삭 톤, 점수 기준, 화면 디자인 등을 바꾸고 싶으면
  `public/index.html`과 `api/feedback.js` 파일을 수정한 뒤 다시 GitHub에
  업로드하면 Vercel이 자동으로 재배포합니다.
- **막히는 부분이 있으면** 언제든 다시 와서 물어보세요 — 스크린샷과 함께
  질문하시면 더 빠르게 도와드릴 수 있어요.

## claude.ai 미리보기와의 차이

이 대화창 안 미리보기 화면에서 테스트했던 버전은 Anthropic(Claude) API를
자동으로 사용하도록 되어 있어서, 그 화면 자체는 OpenAI 키로 테스트할 수 없어요.
지금 이 배포용 코드(`api/feedback.js`)는 OpenAI로 새로 작성한 버전이니,
실제 작동 확인은 반드시 **Vercel 배포 후 생성된 주소**에서 해주세요.

